Bu þablon ile oluþturduðunuz tez taslaklarýnýzýn en baþýna "Tez Þablonu Onay Formu.docx" belgesini imzalayarak eklemeniz gerekmektedir.

-------------------------------------------------------------------------------

You have to sign and add the "Tez Þablonu Onay Formu.docx" document at the beginning of your thesis drafts.